# animacion
2.4. El bucle de juego y la animación
